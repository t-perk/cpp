#pragma once

#include <ATen/ATen.h>

namespace torch {
namespace sparse {

}} // torch::sparse
