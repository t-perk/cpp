#pragma once

#include <torch/csrc/autograd/profiler_legacy.h>
#include <torch/csrc/autograd/profiler_kineto.h>
