#pragma once

namespace torch { namespace autograd { namespace profiler { namespace python_tracer {

void init();

}}}} // namespace torch::autograd::profiler::python_tracer
