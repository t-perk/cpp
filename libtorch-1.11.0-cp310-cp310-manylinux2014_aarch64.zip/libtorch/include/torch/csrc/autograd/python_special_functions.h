#pragma once

namespace torch { namespace autograd {

void initSpecialFunctions(PyObject* module);

}} // namespace torch::autograd
