#undef TH_GENERIC_FILE

#undef THPTensor_
#undef THPTensor_stateless_
#undef THPTensor
#undef THPTensorStr
#undef THPTensorBaseStr
#undef THPTensorClass

#undef THPTensorStatelessType
#undef THPTensorStateless
#undef THPTensorType

#undef THPStorage_
#undef THPStorageBaseStr
#undef THPStorageStr
#undef THPStorageClass
#undef THPStorageType

#undef THPStoragePtr
#undef THPTensorPtr

#undef THWTensor
#undef THWTensor_

#undef THSPTensor_
#undef THSPTensor_stateless_
#undef THSPTensor
#undef THSPTensorStr
#undef THSPTensorBaseStr
#undef THSPTensorClass

#undef THSPTensorStatelessType
#undef THSPTensorStateless
#undef THSPTensorType

#undef THSPTensorPtr
