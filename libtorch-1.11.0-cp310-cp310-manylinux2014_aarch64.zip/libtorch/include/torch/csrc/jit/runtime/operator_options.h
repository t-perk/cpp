#pragma once

#include <ATen/core/dispatch/OperatorOptions.h>

namespace torch {
namespace jit {

using AliasAnalysisKind = c10::AliasAnalysisKind;

} // namespace jit
} // namespace torch
